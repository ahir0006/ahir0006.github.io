The reason behind this specific portfolio was to demonstrate my aptitudes and capacity and likewise, to present myself and bit about my past work to the world with the goal that I can get seen by organizations and get enlisted by one of them in future.

At first, the portfolio was made in light of one objective - MAKE MY WEBSITE LOOK APPEALING.  

While structuring the xd document, I was overpowered thus fussy and chose to make it as well as could be expected and I made a strong model. 

While growing, at first, I began off with my default configuration as indicated by xd document. As I was advancing forward, I understand a couple of the components were dull and totally losing the plan. So I needed to roll out some minor improvements, for example, front fixed extended header region, just as fundamental shape and shade of few catches on a specific segment.

As I progressed I realized I made a better design after the minor changes.

I began off with buoy and flex with a touch of CSS matrix and I was getting a not too bad outcome yet as I structured more compartments, the inconvenience started. The format slanted off from the real thought and it was just deteriorating as I attempted. 

So I chose to scrap off that task and begin once again one with the assistance of bootstrap, jquery, and couple of different modules and well it resembled a missing touch. I was at long last getting the accomplishment with the plan and that is the motivation behind why I picked bootstrap and jquery over unadulterated CSS and js. 

Barely any instances of difficulties would be, the manner by which hard it was without disc sm-6 to make the entire about area. As with CSS and js, I couldn't fit 4 frameworks with content and symbol on a similar section/line.


Introductory issue with a plan caused me to understand that a conceptualizing before making a model or notwithstanding drawing stuff down on paper would enable me to acknowledge how I wanna approach a specific structure. 

Understanding the need of a plan as per an undertaking, structuring a reasonable model and know the apparatuses and innovation to use to accomplish that plan, this ought to be conceptualized heretofore, doing as such would facilitate the pressure and help spare some time.

Thanks to the open-source software distribution act, web development has become very easy. List of Plugins/Frameworks/Libraries I used to achieve the final result.

1. [Html]

2. [CSS]

3. [Bootstrap](https://getbootstrap.com/) 

4. [jQuery](https://getbootstrap.com/)

5.  [Animate.css](https://daneden.github.io/animate.css/)


Images were taken from [Unsplash](https://www.Unsplash.com/) (Thank you for royalty-free photos)